package com.tony.distance;

import java.util.Comparator;

public class PointComparator implements Comparator<Point> {

	private Point center;
	
	public PointComparator(Point center) {
		this.center = center;
	}

	@Override
	public int compare(Point p1, Point p2) {

		double d1 = Math.sqrt(Math.pow(p1.getX() - center.getX(), 2.0)
				+ Math.pow(p1.getY() - center.getY(), 2.0));
		double d2 = Math.sqrt(Math.pow(p2.getX() - center.getX(), 2.0)
				+ Math.pow(p2.getY() - center.getY(), 2.0));

		if (d1 < d2) {
			return -1;
		}
		if (d1 > d2) {
			return 1;
		}
		return 0;
	}
}
