package com.tony.distance;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Plane p = new PlaneImpl(); 
		// (0, 1) (0, 2) (0, 3) (0, 4) (0, 5) 
		p.addPoint(new Point(0,1)); 
		p.addPoint(new Point(0,2)); 
		p.addPoint(new Point(0,3)); 
		p.addPoint(new Point(0,4)); 
		p.addPoint(new Point(0,5)); 
		
		System.out.println(p.findNearest(new Point(0, 2), 3));
	}

}
