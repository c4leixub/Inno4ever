package com.tony.distance;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.PriorityQueue;

public class PlaneImpl implements Plane {
	
	private Collection<Point> points;

	public PlaneImpl() {
		this.points = new ArrayList<Point>();
	} 

	@Override
	public void addPoint(Point point) {
		
		for (Point p : points) {
			if (p.getX() == point.getX() && p.getY() == point.getY()) {
				return;
			}
		}
		points.add(point);
	}

	@Override
	public Collection<Point> findNearest(Point center, int m) {
		
		/*
		 * each insertion to the queue is log n, so the loop takes n log n where n is number of element
		 * in the collection
		 */
		PriorityQueue<Point> queue = new PriorityQueue<Point>(m, new PointComparator(center));
		for (Point p : points) {
			if (p.getX() != center.getX() || p.getY() != center.getY()) {
				queue.add(p);
			}
		}
		
		/*
		 * each poll from the PriorityQueue is contant time, so the loop take m time
		 */
		Collection<Point> result = new ArrayList<Point>();
		for (int i = 0; i != m && !queue.isEmpty(); i++) {
			result.add(queue.poll());
		}
		
		
		/*
		 * Overall, the total complexity is m + n log n => n log n
		 */
		return result;
	}

}
