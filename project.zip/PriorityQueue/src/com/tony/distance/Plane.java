package com.tony.distance;

import java.util.Collection;

public interface Plane {

	void addPoint(Point point);
	Collection<Point> findNearest(Point center, int m);
}
