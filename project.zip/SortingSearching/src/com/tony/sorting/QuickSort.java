package com.tony.sorting;

public class QuickSort {
	
	public static void quickSort(int arr[], int left, int right) {
		int index = partition(arr, left, right);
		
		// sort left half
		if (left < index - 1) {
			quickSort(arr, left, index - 1);
		}	

		// sort right half
		if (index < right) {
			quickSort(arr, index, right);
		}
	}

	public static int partition(int arr[], int left, int right) {
		int pivot = arr[(left + right)/2];
		while (left <= right) {
			// Find element on left that should be on right
			while (arr[left] < pivot) left++;

			// Find element on right that should be on left
			while (arr[right] > pivot) right++;

			// Swap elements, and move left and right indices
			if (left <= right) {
				swap(arr, left, right);
				left++;
				right--;
			}
		}

		return left;
	}

	public static void swap(int arr[], int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
}
