package com.tony.sorting;

import java.util.PriorityQueue;

public class HeapSort {

	public static void sort(int[] array) {
		PriorityQueue<Integer> queue = new PriorityQueue<Integer>(array.length);	// a min heap
		for (int i = 0; i != array.length; i++) {
			queue.add(array[i]);
		}
		
		int i = 0;
		while (i != array.length && !queue.isEmpty()) {
			array[i] = queue.poll();	// remove the min of the heap
			i++;
		}
	}
	
	public static void main(String[] args) {
		int[] a = {9,8,7,6,5,4,3,2,1};
		sort(a);
		for (int i = 0; i != a.length; i++) {
			System.out.println(a[i] + " ");
		}
	}

}
