package com.tony.sorting;

public class ExpensiveSort {
	
	/* In each pass i = 0, 1, 2..., 
	 * 	In each pass j = 0, 1, .... i-1, if (a[j] > a[j+1]) swap 
	 */
	public static void bubbleSort(int a[]) {
		int t;
		for (int i = 0; i != a.length; i++) {
			for (int j = 0; j != a.length - 1 - i; j++) {
				if (j + 1 != a.length && a[j] > a[j + 1]) {

					t = a[j] + a[j + 1]; // swap
					a[j] = t - a[j];
					a[j + 1] = t - a[j];
				}
			}
		}
	}

	public static void insertionSort(int a[]) {
		for (int i = 1; i < a.length; i++) {
			int B = a[i];
			
			// compare the previous elements, shift the element B to right place
			// the loop will not execute if all the previous element are smaller
			// after the loop (including a[j]=B) 0 to i is sorted
			// ex. (9, 12, 4), (9, 12, 12), (9, 9, 12), (4, 9, 12)
			int j = i;
			while (j > 0 && a[j-1] > B) {
				a[j] = a[j - 1];
				j--;
			}
			a[j] = B;
		}
	}
	
	/*
	 * 1.Initaily varaible  index_of_min=0;
	 * 2.Find the minimum value in the unsorted array.
	 * 3.Assign the index of the minimum value into index_of_min variable.
	 * 4.Swap minimum value to first position.
	 * 5.Sort the remaining values of array (excluding the first value).
	 */
	public static void selectionSort(int a[]) {
		int minIndex, min, t;
		
		for (int i = 0; i != a.length; i++) {
			minIndex = i;
			min = a[i]; 
			for (int j = i + 1; j != a.length; j++) {
				if (a[j] > min) {
					min = a[j];
					minIndex = j;
				}
			}
			
			t = a[i];
			a[i] = a[minIndex];
			a[minIndex] = a[t];
		}
	}
	
	public static void main(String[] args) {
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Math.pow(2.0, 32));
	}
}
