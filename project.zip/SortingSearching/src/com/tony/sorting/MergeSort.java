package com.tony.sorting;

public class MergeSort {

	public static void mergeSort(int[] array) {
		int[] helper = new int[array.length];
		mergeSort(array, helper, 0, array.length - 1);
	}
	
	private static void mergeSort(int[] array, int[] helper, int low, int high) {
		if (low < high) {
			int mid = (low + high) / 2;
			mergeSort(array, helper, low, mid);
			mergeSort(array, helper, mid+1, high);
			merge(array, helper, low, mid, high);
		}
	}
	
	/**
	 * Iterate through helper array. Compare the left and right half, copy back the smaller
	 * element from the two halves into the original array
	 */
	private static void merge(int[] array, int[] helper, int low, int mid, int high) {
		// get a copy of the array
		for (int i = low; i <= high; i++) {
			helper[i] = array[i];
		}
		
		int left = low;
		int right = mid + 1;
		int current = low;
		
		while (left <= mid && right <= high) {
			if (helper[left] <= helper[right]) {
				array[current] = helper[left];
				left++;
			} else {
				array[current] = helper[right];
				right++;
			}
			
			current++;
		}
		
		/*
		 * Copy the rest of the left side of the array into
		 * the target array, the loop run when the left
		 * array has element bigger than all the element
		 * in the right array
		 */
		int remain = mid - left;
		for (int i = 0; i <= remain; i++) {
			array[current + i] = helper[left + i];
		}
	}

}
