package com.tony.searching;

import java.util.Stack;

public class DepthFirstSeach {

	public static void traverse(Node root) {
		
		if (root == null) return;
		
		Stack<Node> stack = new Stack<Node>();
		System.out.print(root.value + " ");
		stack.push(root);
		
		while (!stack.isEmpty()) {
			Node node = stack.peek();
			System.out.print(node.value + " ");
			
			// the three statements is equivalent to getUnvisitChild 
			if (node.numVisit != node.children.size()) {
				Node child = node.children.get(node.numVisit);
				node.numVisit++;
				
				stack.push(child);
			} else {
				stack.pop();
			}
			
		}
	}

}
