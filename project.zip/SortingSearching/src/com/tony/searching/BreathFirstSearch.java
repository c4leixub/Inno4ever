package com.tony.searching;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class BreathFirstSearch {

	/*
	 * Time and space complexity is O(b ^ d), 
	 * where b is the branch factor (i.e. how many child in a node)
	 * d is the deepest level
	 */
	public static boolean search(Node root, int i) {
		
		if (root == null) return false;
		
		Queue<Node> queue = new LinkedList<Node>();
		queue.add(root);
		
		while (!queue.isEmpty()) {
			Node node = queue.poll();
			if (node.value == i) return true;
				
			// the for statements is equivalent to getUnvisitChild 
			for (Node n : node.children) {
				
				if (n.value == i) return true;
				queue.add(n);
			}
		}
		
		return false;
	}
	
	public static void main(String[] args) {
		Queue<Node> queue = new LinkedList<Node>();
		queue.add(new Node(11));
		queue.add(new Node(10));
		
		while (!queue.isEmpty()) {
			System.out.println(queue.poll().value);
		}
	}

}
