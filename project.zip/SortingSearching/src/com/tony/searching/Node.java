package com.tony.searching;

import java.util.ArrayList;
import java.util.List;

public class Node {

	public int value;
	public List<Node> children;
	public int numVisit;
	
	public Node(int i) {
		value = i;
		children = new ArrayList<Node>();
		numVisit = 0;
	}

}
