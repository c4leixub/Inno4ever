package com.sns.path;

public class Machine {

	public Person getPersonWithID(int personID) {
		// TODO Auto-generated method stub
		return null;
	}

}
