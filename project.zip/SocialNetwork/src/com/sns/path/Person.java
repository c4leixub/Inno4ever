package com.sns.path;

import java.util.ArrayList;

public class Person {

	private ArrayList<Integer> friends = new ArrayList<Integer>();
	private String info;
	private Integer id;
	
	public Person(ArrayList<Integer> friends, String info, Integer id) {
		this.friends = friends;
		this.info = info;
		this.id = id;
	}

	public Integer getID() {
		return this.id;
	}
	
	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setFriends(ArrayList<Integer> friends) {
		this.friends = friends;
	}

	public ArrayList<Integer> getFriends() {
		return this.friends;
	}

}
