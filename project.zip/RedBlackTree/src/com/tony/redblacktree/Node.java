package com.tony.redblacktree;

public class Node {

	public Node left;
	public Node right;
	public int value;
	public boolean isRed;
	
	public Node(Node left, Node right, int value, boolean isRed) {
		super();
		this.left = left;
		this.right = right;
		this.value = value;
		this.isRed = isRed;
	}

}
