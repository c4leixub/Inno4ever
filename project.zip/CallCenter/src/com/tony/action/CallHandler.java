package com.tony.action;

import java.util.ArrayList;
import java.util.List;

import com.tony.domain.Call;
import com.tony.domain.Employee;
import com.tony.domain.Rank;

public class CallHandler {

	private List<Employee> respondents;
	private List<Employee> managers;
	private List<Employee> directors;

	public CallHandler() {
		respondents = new ArrayList<Employee>();
		managers = new ArrayList<Employee>();
		directors = new ArrayList<Employee>();
	}

	public void addEmployee(Employee e) {
		if (e.getRank().equals(Rank.RESPONDENT)) {
			respondents.add(e);
		} else if (e.getRank().equals(Rank.MANAGER)) {
			managers.add(e);
		} else if (e.getRank().equals(Rank.DIRECTOR)) {
			directors.add(e);
		}
	}

	public void dispatchCall(Call c) {
		if (c.isEscalate()) {
			Employee e = c.getEmployee() != null ? getNextLevelFreeEmployee(c) : nextFreeEmployee();
			c.setEmployee(e);
			c.setEscalate(false);
			e.setCall(c);
		} else {
			Employee e = this.nextFreeEmployee();
			c.setEmployee(e);
			c.setEscalate(false);
			e.setCall(c);
		}
	}

	private Employee getNextLevelFreeEmployee(Call c) {
		Employee e = c.getEmployee();
		if (e.getRank().equals(Rank.RESPONDENT)) {
			Employee employee = nextFreeEmployee(Rank.MANAGER);
			if (employee == null)
				employee = nextFreeEmployee(Rank.DIRECTOR);

			return employee;
		} else if (e.getRank().equals(Rank.MANAGER)) {
			return nextFreeEmployee(Rank.DIRECTOR);
		}
		
		return null;
	}

	private Employee nextFreeEmployee(Rank rank) {
		List<Employee> employees;

		if (rank != null) {
			if (rank.equals(Rank.RESPONDENT)) {
				employees = respondents;
			} else if (rank.equals(Rank.MANAGER)) {
				employees = managers;
			} else if (rank.equals(Rank.DIRECTOR)) {
				employees = directors;
			} else {
				return null;
			}

			for (Employee e : employees) {
				if (e.isFree()) {
					return e;
				}
			}
		}
		return null;
	}

	private Employee nextFreeEmployee() {
		Employee e = nextFreeEmployee(Rank.RESPONDENT);
		if (e == null)
			e = nextFreeEmployee(Rank.MANAGER);
		if (e == null)
			e = nextFreeEmployee(Rank.DIRECTOR);

		return e;
	}

}
