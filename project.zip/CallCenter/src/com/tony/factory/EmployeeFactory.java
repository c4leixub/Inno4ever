package com.tony.factory;

import java.util.UUID;

import com.tony.domain.Director;
import com.tony.domain.Employee;
import com.tony.domain.Manager;
import com.tony.domain.Respondent;

public class EmployeeFactory {

	private static EmployeeFactory instance;
	
	public synchronized static EmployeeFactory getInstance() {
		if (instance == null) {
			instance = new EmployeeFactory();
		}
		
		return instance;
	}
	
	public Employee getEmployee(String type, String name) {
		if (type.equalsIgnoreCase("respondent")) {
			return new Respondent(UUID.randomUUID().toString(), name);
		} else if (type.equalsIgnoreCase("manager")) {
			return new Manager(UUID.randomUUID().toString(), name);
		} else if (type.equalsIgnoreCase("director")) {
			return new Director(UUID.randomUUID().toString(), name);
		}
		
		return null;
	}

}
