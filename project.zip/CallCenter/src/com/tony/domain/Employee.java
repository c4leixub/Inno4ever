package com.tony.domain;

public abstract class Employee {

	protected String id;
	protected String name;
	protected Rank rank;
	protected Call call;
	
	
	public Employee(String id, String name) {
		super();
		this.id = id;
		this.name = name;
		this.rank = rank;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Rank getRank() {
		return rank;
	}
	public void setRank(Rank rank) {
		this.rank = rank;
	}
	public Call getCall() {
		return call;
	}
	public void setCall(Call call) {
		this.call = call;
	}
	public boolean isFree() {
		return call != null;
	}
	
	

}
