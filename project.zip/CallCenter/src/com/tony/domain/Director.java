package com.tony.domain;

public class Director extends Employee {

	public Director(String id, String name) {
		super(id, name);
		rank = rank.DIRECTOR;
	}

}
