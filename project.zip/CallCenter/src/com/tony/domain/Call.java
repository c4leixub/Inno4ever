package com.tony.domain;

public class Call {

	private String id;
	private String issue;
	private String reply;
	private Employee employee;
	private boolean escalate;
	
	public Call(String id, String issue) {
		super();
		this.id = id;
		this.issue = issue;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public boolean isEscalate() {
		return escalate;
	}

	public void setEscalate(boolean escalate) {
		this.escalate = escalate;
	}
	
	

}
