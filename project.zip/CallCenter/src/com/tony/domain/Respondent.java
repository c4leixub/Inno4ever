package com.tony.domain;

public class Respondent extends Employee{
	
	public Respondent(String id, String name) {
		super(id, name);
		this.rank = Rank.RESPONDENT;
	}

}
