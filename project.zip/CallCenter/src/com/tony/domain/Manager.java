package com.tony.domain;

public class Manager extends Employee {

	public Manager(String id, String name) {
		super(id, name);
		rank = Rank.MANAGER;
	}
	
	

}
