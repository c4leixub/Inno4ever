package com.tony.domain;

public class Rank {
	
	public static Rank RESPONDENT = new Rank("Respondent");
	public static Rank MANAGER = new Rank("Manager");
	public static Rank DIRECTOR = new Rank("Director");

	private String title;
	
	public Rank(String title) {
		super();
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rank other = (Rank) obj;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	
}
