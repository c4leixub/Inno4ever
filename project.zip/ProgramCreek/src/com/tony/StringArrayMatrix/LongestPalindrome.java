package com.tony.StringArrayMatrix;

public class LongestPalindrome {

	public static void longestPalindrome(String s) {	// Time O(n^2) Space O(n^2)
		if (s == null || s.length() <= 1) {
			System.out.println(s);
			return;
		}

		int n = s.length();
		boolean[][] table = new boolean[n][n];

		// All substring of length 1 are palindrome
		int maxLength = 1;
		for (int i = 0; i < n; i++) {
			table[i][i] = true;
		}

		int start = 0;
		// check for sub-string of length 2.
		for (int i = 0; i < n - 1; i++) {
			if (s.charAt(i) == s.charAt(i + 1)) {
				table[i][i + 1] = true;
				start = i;
				maxLength = 2;
			}
		}

		// Check for lengths greater than 2. k is length of substring
		for (int k = 3; k < n; k++) {
			for (int i = 0; i + k < n; i++) { // for each substring of length k
				int j = i + k - 1; // the last char position of the substring

				// i is first char pos in the substring, check
				// charAt(i)==charAt(j)
				// we already store the result the substring from [i+1, j-1] in
				// the table, use it to compare the result
				if (table[i + 1][j - 1] && s.charAt(i) == s.charAt(j)) {

					// update the table
					table[i][j] = true;

					// update the start point the substring and length
					if (k > maxLength) {
						start = i;
						maxLength = k;
					}
				}
			}
		}

		System.out.println("Longest palindrome substring is: ");
		System.out.println(s.substring(start, start + maxLength));
	}

	public String longestPalindrome2(String s) {	// Time O(n^2), Space O(1)
		if (s.isEmpty()) {
			return null;
		}

		if (s.length() == 1) {
			return s;
		}

		String longest = s.substring(0, 1);
		for (int i = 0; i < s.length(); i++) {
			// get longest palindrome with center of i
			String tmp = helper(s, i, i);
			if (tmp.length() > longest.length()) {
				longest = tmp;
			}

			// get longest palindrome with center of i, i+1
			tmp = helper(s, i, i + 1);
			if (tmp.length() > longest.length()) {
				longest = tmp;
			}
		}

		return longest;
	}

	// Given a center, either one letter or two letter,
	// Find longest palindrome
	public String helper(String s, int begin, int end) {
		while (begin >= 0 && end <= s.length() - 1
				&& s.charAt(begin) == s.charAt(end)) {
			begin--;
			end++;
		}
		return s.substring(begin + 1, end);
	}

	public static void main(String[] s) {
		longestPalindrome("forgeeksskeegfor");
	}

}
