package com.tony.StringArrayMatrix;

import java.util.Arrays;
import java.util.HashSet;

/*
 * Given an array of integers, find two numbers such that they add up to a specific target number.
 */
public class TwoSum {

	public int[] twoSum(int[] numbers, int target) {
		HashSet<Integer> set = new HashSet<Integer>();
		int[] result = new int[2];

		for (int i = 0; i < numbers.length; i++) {
			if (set.contains(numbers[i])) {
				result[0] = numbers[i];
				result[1] = target - numbers[i];
				break;
			} else {
				set.add(target - numbers[i]);
			}
		}

		return result;
	}
	
	public int[] twoSum2(int[] numbers, int target) {
		Arrays.sort(numbers);
		int[] result = new int[2];

		int i = 0, j = numbers.length - 1;
		while (i != j) {
			if (i + j == target) {
				result[0] = numbers[i];
				result[1] = numbers[j];
				break;
			} else if (i+j < target) {
				i++;
			} else {
				j--;
			}
		}

		return result;
	}

}
