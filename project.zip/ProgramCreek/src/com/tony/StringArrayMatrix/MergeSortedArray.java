package com.tony.StringArrayMatrix;

public class MergeSortedArray {

	/*
	 * Given two sorted integer arrays A and B, merge B into A as one sorted array.
	  	A has m element, A[m+1]...A[m+n] are empty, and n is the length of B
	 */
	public void merge(int A[], int m, int B[], int n) {

		while (m > 0 && n > 0) {
			if (A[m - 1] > B[n - 1]) {
				A[m + n - 1] = A[m - 1];
				m--;
			} else {
				A[m + n - 1] = B[n - 1];
				n--;
			}
		}
		
		while (n > 0) {
			A[m + n - 1] = B[n - 1];
			n--;
		}
	}

}
