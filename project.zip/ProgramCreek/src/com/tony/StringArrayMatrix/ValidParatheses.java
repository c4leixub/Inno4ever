package com.tony.StringArrayMatrix;

import java.util.Stack;

public class ValidParatheses {

	public static boolean isValid(String s) {
		char[] charArray = s.toCharArray();
	 
		Stack<Character> stack = new Stack<Character>();
	 
		for (Character c : charArray) {
			if (c == '(') {
				stack.push(c);
			} else if (c == ')') {
				if (!stack.isEmpty()) {
					stack.pop();
				} else {
					return false;
				}
			}
		}
		return stack.isEmpty();
	}

}
