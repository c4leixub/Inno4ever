package com.tony.StringArrayMatrix;

public class MaxArrayDistance {

	public static int maxIndexDiffInefficient(int[] A) {
		return 0;
	}
	
	public static int maxIndexDiff(int[] A) {
		int[] LMin = new int[A.length];
		int[] RMax = new int[A.length];

		// set each element to the min from A[0] to A[i]
		LMin[0] = A[0];
		for (int i = 1; i < A.length; i++) {
			LMin[i] = Math.min(A[i], LMin[i - 1]);
		}

		// set each element to the max from A[i] to A[A.length - 1]
		RMax[A.length - 1] = A[A.length - 1];
		for (int i = A.length - 2; i >= 0; i--) {
			RMax[i] = Math.max(A[i], RMax[i + 1]);
		}

		int i = 0, j = 0, n = A.length, maxDiff = -1;
		while (j < n && i < n) {
			if (LMin[i] < RMax[j]) {
				maxDiff = Math.max(maxDiff, j - i);
				j = j + 1;
			} else
				i = i + 1;
		}

		return maxDiff;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {34, 8, 10, 3, 2, 80, 30, 33, 1};
		System.out.print(maxIndexDiff(arr));
	}

}
