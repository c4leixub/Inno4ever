package com.tony.LinkListStackQueue;

public class ConvergeLinkedList {

	public class Node {
		Node next;
		int value;
	}
	
	public Node getStartConvergeNode(Node A, Node B) {
		
		int m = 0;
		Node cur = A;
		while (cur != null) {
			m++;
			cur = cur.next;
		}
		
		int n = 0;
		cur = B;
		while (cur != null) {
			m++;
			cur = cur.next;
		}
		
		Node L = m > n ? A : B;
		Node S = L == A ? B : A;
		
		for (int i = 0; i < Math.abs(m-n); i++) {
			L = L.next;
		}
		
		while (L != S) {
			L = L.next;
			S = S.next;
			
			if (L == null || S == null)	return null;
		}
		
		return L;
	}

}
