package com.tony.LinkListStackQueue;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

public class MergeKSortedLists {

	public static ListNode mergeKLists(ArrayList<ListNode> lists) {
		if (lists.size() == 0)
			return null;

		ListNode fakeHead = new ListNode(0);
		ListNode p = fakeHead;

		PriorityQueue<ListNode> q = new PriorityQueue<ListNode>(lists.size(),
				new Comparator<ListNode>() {

					@Override
					public int compare(ListNode a, ListNode b) {
						if (a.val > b.val)
							return 1;
						else if (a.val == b.val)
							return 0;
						else
							return -1;
					}

				});

		// add first node of each list to the queue
		for (ListNode node : lists) {
			if (node != null)
				q.add(node);
		}

		while (q.size() > 0) {
			ListNode n = q.poll();
			p.next = new ListNode(n.val);

			if (n.next != null)
				q.add(n.next);
			p = p.next;
		}

		return fakeHead.next;
	}

	public static void main(String[] args) {}

}
