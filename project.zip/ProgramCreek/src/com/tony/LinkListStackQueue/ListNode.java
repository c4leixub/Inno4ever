package com.tony.LinkListStackQueue;

public class ListNode {

	public ListNode next;
	public int val;
	
	ListNode(int x) {
		val = x;
		next = null;
	}
}
