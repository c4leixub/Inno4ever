package com.tony.LinkListStackQueue;

public class MergeTwoSortedLists {

	public ListNode merge(ListNode l1, ListNode l2) {
		
		ListNode result = null;
		
		ListNode p1 = l1;
		ListNode p2 = l2;
		ListNode p3 = result;
		
		while (p1 != null || p2 != null) {
			ListNode n;
			
			if (p2 == null || p1.val < p2.val ) {
				n = new ListNode(p1.val);
				p1 = p1.next;
			} else {
				n = new ListNode(p2.val);
				p2 = p2.next;
			}
			
			if (result == null) {
				result = n;
				p3 = result;
			} else {
				p3.next = n;
				p3 = p3.next;
			}
		}
		
		return result;
		
	}

}
