package com.tony.LinkListStackQueue;

import java.util.HashMap;

/*
 * A linked list is given such that each node contains an additional random pointer
 * which could point to any node in the list or null. Return a deep copy of the list
 */
public class CopyListWithRandomPointer {

	class RandomListNode {

		RandomListNode next;
		RandomListNode random;
		int val;
		
		RandomListNode(int x) {
			val = x;
			next = null;
		}
	}
	
	public RandomListNode copyRandomListNode(RandomListNode head) {
		
		if (head == null)	return null;
		
		// key: old node, value : new node
		// let x be a node, y be the random of x, after copy we get x' 
		// and because we have a map, we can determine x -> x'
		// to connect x' with y', use x'.random = map.get(x.random = y) = y'
		HashMap<RandomListNode, RandomListNode> map = new HashMap<RandomListNode, RandomListNode>();
		
		RandomListNode newHead = new RandomListNode(head.val);
		
		RandomListNode p = head;
		RandomListNode q = newHead;
		map.put(head, newHead);
		p = p.next;
		
		while (p != null) {
			RandomListNode n = new RandomListNode(p.val);
			map.put(p, n);
			q.next = n;
			
			p = p.next;
			q = q.next;
		}
		
		p = head;
		q = newHead;
		while (p != null) {
			if (p.random != null) {
				q.random = map.get(p.random);
			}
			
			p = p.next;
			q = q.next;
		}
		
		return newHead;
	}
}
