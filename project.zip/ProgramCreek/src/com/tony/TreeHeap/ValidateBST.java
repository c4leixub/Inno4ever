package com.tony.TreeHeap;

public class ValidateBST {

	public static TreeNode prev = null;
	
	public static boolean validate(TreeNode root) {
		if (root != null) {
			
			if (!validate(root.left)) return false;
			
			if (prev != null && prev.value > root.value) return false;
			
			prev = root;
			
			return validate(root.right);
			
		}
		
		return true;
	}

}
