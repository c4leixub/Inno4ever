package com.tony.TreeHeap;

public class FindLargestNode {

	public static TreeNode findLargest(TreeNode root) {
		if (root == null) return null;
		
		TreeNode left = findLargest(root.left);
		TreeNode right = findLargest(root.right);
		
		if (left == null && right == null) {
			return root;
		} else if (right == null) {
			return root.value > left.value ? root : left;
		} else if (left == null) {
			return root.value > right.value ? root : right;
		} else {
			TreeNode max = left.value > right.value ? left : right;
			max = root.value > max.value ? root : max;
			return max;
		}
	}
}