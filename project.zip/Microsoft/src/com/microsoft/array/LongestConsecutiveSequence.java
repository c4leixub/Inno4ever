package com.microsoft.array;

import java.util.HashSet;

/*
 * Ex. Given [100, 4, 200, 1, 3, 2] , The longest consecutive elements sequence is
 * [1, 2, 3, 4] . Return its length: 4 .
 */
public class LongestConsecutiveSequence {

	public static int findLCS(int[] A) {
		HashSet<Integer> m = new HashSet<Integer>();
		for (int e : A) {
			if (!m.contains(e)) {
				m.add(e);
			}
		}
		
		int max = 1;
		for (Integer e : A) {
			int count = 1;
			int pre = e - 1;
			while (m.contains(pre)) {
				count++;
				m.remove(pre);
				pre--;
			}
			
			int next = e + 1;
			while (m.contains(next)) {
				count++;
				m.remove(next);
				next++;
			}
			
			max = Math.max(max, count);
			
			if (m.isEmpty()) // end the loop earlier
				break;
		}
		
		return max;
	}
	
	public static void main(String[] args) {
		int[] A = new int[] {100, 4, 200, 1, 3, 2};
		System.out.println(findLCS(A));
	}
}
