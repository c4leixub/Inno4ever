package com.microsoft.array;

public class CompareVersion {
	public static int compareVersio2(String version1, String version2) {
        String[] t1 = version1.split("\\.");
        String[] t2 = version2.split("\\.");
        
        int i= 0, j=0;
        while (i < t1.length && j < t2.length) {
            int c = t1[i].compareTo(t2[j]);
            if (c > 0) {
            	return 1;
            } else if (c < 0) {
            	return -1;
            }
            i++;
            j++;
        }
        
        if (i < t1.length) {
        	return 1;
        } else if (j < t2.length) {
        	return -1;
        }
        
        return 0;
    }
	
	public static int compareVersion(String version1, String version2) {
        int v1 = 0;
        int v2 = 0;
        
        int i= 0, j = 0;
        while (i < version1.length() || j < version2.length()) {
            while(i < version1.length() && version1.charAt(i) != '.') {
            	v1 = v1 * 10 
            			+ (((int) version1.charAt(i)) - 48);
            	i++;
            }
            while(j < version2.length() && version2.charAt(j) != '.') {
            	v2 = v2 * 10 
            			+ (((int) version2.charAt(j)) - 48);
            	j++;
            }
            
            if (v1 > v2) {
            	return 1;
            } else if (v1 < v2) {
            	return -1;
            }
            	
            i++;
            j++;
            
            v1 = 0;
            v2 = 0;
        }
        
        return 0;
	}
	
	public static void main(String[] args) {
		System.out.println(compareVersion("1.2.1","1.2.1"));
		
		System.out.println(compareVersion("1.2.3","1.2.1"));
		System.out.println(compareVersion("1.2.5","1.2.9"));
		
		System.out.println(compareVersion("1.2.3","1.2.3.1"));
		
		System.out.println(compareVersion("1.5","1.4.3.1"));
		System.out.println(compareVersion("3.2","2.0"));
		
		System.out.println(compareVersion("3.2",""));
		System.out.println(compareVersion("","2.0"));
	}
}
