package com.microsoft.array;

public class Utils {

	public static void printArray(Object[] o) {
		for (int i = 0; i != o.length; i++) {
			System.out.print(o[i]);
			System.out.print(" ");
		}
		System.out.println();
	}
	
	public static void printIntArray(int[] o) {
		for (int i = 0; i != o.length; i++) {
			System.out.print(o[i]);
			System.out.print(" ");
		}
		System.out.println();
	}
}
