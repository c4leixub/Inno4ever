package com.microsoft.array;

public class MaxSubArray {

	public static int maxSubArray(int[] A) {
		if (A == null || A.length == 0) return 0;
		
		int cur = A[0];
		int max = A[0];
		for (int i = 1; i < A.length; i++) {
			cur = cur + A[i];
			Math.max(max, cur);
		}
		
		return max;
	}
}
