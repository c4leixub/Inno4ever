package com.microsoft.array;

import java.util.Arrays;

/**
Given two arrays were digits of one array represent a number,
maxmise the number by replacing it with elements of second array. 
eg: 
arr={3,1,4,5,6} 
rep={1,9,5,2,3} 

after replacement 
arr={9,5,4,5,6} 
one digit of rep can be used to replace only once.
 */
public class ArrayOneElemReplaceOfMaxArrayTwo {

	public static void maximise(Integer[] arr1, Integer[] arr2) {
		
		if (arr1 == null || arr2 == null || arr1.length == 0)
			return;
		
		Arrays.sort(arr2);
		
		int max = arr2.length-1;
		for (int i = 0; i < arr1.length; i++) {
			if (arr1[i] < arr2[max]) {
				arr1[i] = arr2[max];
				max--;
			}
		}
	}
	
	public static void main(String[] args) {
		Integer[] arr1 = {3,1,4,5,6};
		Integer[] arr2 = {1,9,5,2,3};
		maximise(arr1, arr2);
		Utils.printArray(arr1);
		
		maximise(null, null);
	}
}
