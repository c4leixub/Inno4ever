package com.microsoft.string;

/**
 * Reverse string except spaces. A string has mix of alphabets and spaces. 
 * Your task is to reverse the string, but preserve the positions of spaces. 
 * For example, reverse of " a if" is " f ia".
 * @author dij052
 *
 */
public class ReverseStringExceptSpace {

	public static String reverseStringExceptSpace(String s) {
		String result = "";
		
		int i = 0;
		int j = s.length() - 1;
		while(i < s.length()) {
			if (s.charAt(i) != ' ' && s.charAt(j) != ' ') {
				result += s.charAt(j);
				i++;
				j--;
			} else if (s.charAt(i) == ' ') {
				result += ' ';
				i++;
			} else if (s.charAt(j) == ' ') {
				j--;
			} else {
				result += ' ';
				i++;
				j--;
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		System.out.println(reverseStringExceptSpace("I am Tony Lei"));
	}
	
}
