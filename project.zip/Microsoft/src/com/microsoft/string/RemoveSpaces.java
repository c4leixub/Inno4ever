package com.microsoft.string;

/**
 * Remove the space in head and rear, make sure only one space between words
 */
public class RemoveSpaces {

	public static String removeSpaces(String s) {
		if (s == null) return null;
		
		s = s.trim();	// remove head and rear
		
		String result = "";
		boolean flag = true;		// this flag means a space is needed
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) != ' ') {
				result += s.charAt(i);
				flag = true;
			} else {		
				if (flag) {
					result += s.charAt(i);
					flag = false;
				}
			}
		}
		
		return result;
	}
}
