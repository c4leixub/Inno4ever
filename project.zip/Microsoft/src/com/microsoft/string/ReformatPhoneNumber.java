package com.microsoft.string;

public class ReformatPhoneNumber {

	public static void reformat(String[] phoneNumbers) {
		
		for (int i = 0; i < phoneNumbers.length; i++) {
			if (phoneNumbers[i].charAt(3) == '-') {
				phoneNumbers[i] = phoneNumbers[i].substring(4, 7) + "-"
						+ phoneNumbers[i].substring(0, 3) + "-"
						+ phoneNumbers[i].substring(8);
			} else {
				phoneNumbers[i] = phoneNumbers[i].substring(3, 6) + "-"
						+ phoneNumbers[i].substring(0, 3) + "-"
						+ phoneNumbers[i].substring(6);
			}
		}
	}
	
	public static void main(String[] args) {
		String[] phoneNumbers = {"1234567890", "123-456-7890"};
		reformat(phoneNumbers);
		for (int i = 0; i < phoneNumbers.length; i++) {
			System.out.println(phoneNumbers[i]);
		}
	}
	
}
