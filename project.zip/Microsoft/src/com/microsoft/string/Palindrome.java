package com.microsoft.string;

public class Palindrome {
	public static boolean isPalindrome(String s) {
        s = s.toLowerCase();
        int i = 0, j = s.length() - 1;
        while (i < j) {
        		char ci = convert(s.charAt(i));
        		char cj = convert(s.charAt(j));
        		if (ci == '#') {
        			i++;
        		} else if (cj == '#') {
        			j--;
        		} else if (ci != cj) {
        			return false;
        		} else {
        			i++;
        			j--;
        		}
        }
        
        return true;
    }
	
	public static char convert(char c) {
		if ((65 <= c && c <= 90)
				|| (48 <= c && c <= 57)) {
			return c;
		} else if (97 <= c && c <= 122) {
			return (char) (65 + ((int) c) % 97);
		}
		return '#';
	}
	
	public static void main(String[] args) {
//		System.out.println(isPalindrome("A man, a plan, a canal: Panama"));
//		System.out.println(isPalindrome("AmanaplanacanalPanama"));
//		System.out.println(isPalindrome("race a car"));
		System.out.println(convert('p'));
		System.out.println(convert('P'));
		System.out.println(convert('1'));
		System.out.println(convert('*'));
		System.out.println(isPalindrome("0P"));
	}
}
