package com.microsoft.integer;

public class Atoi {
	public int myAtoi(String str) {
		while (str.length() > 0 && str.charAt(0) == ' ') {
			str = str.substring(1);
		}
		if (str.length() == 0)
			return 0;

		boolean isNegative = false;
		if (str.charAt(0) == '-') {
			isNegative = true;
			str = str.substring(1);
		} else if (str.charAt(0) == '+') {
			str = str.substring(1);
		}

		int i = 0;
		long result = 0;
		while (i < str.length()) {
			long d = ((int) str.charAt(i)) - 48;
			if (0 <= d && d <= 9) {
				result = result * 10 + d;

				if (isNegative) {
					result = result * -1;
				}
				if (result > Integer.MAX_VALUE) {
					return Integer.MAX_VALUE;
				}
				if (result < Integer.MIN_VALUE) {
					return Integer.MIN_VALUE;
				}

			} else {
				break;
			}
			i++;
		}

		return (int) result;
	}

	public static void main(String[] args) {
		Atoi a = new Atoi();
		System.out.println(a.myAtoi("9223372036854775809"));
		
	}
}
