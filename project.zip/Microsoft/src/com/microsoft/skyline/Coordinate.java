package com.microsoft.skyline;

public class Coordinate {
	public int start;
	public int end;
	public int height;
	
	public Coordinate(int start, int end, int height) {
		super();
		this.start = start;
		this.end = end;
		this.height = height;
	}
}
