package com.microsoft.skyline;

public class Point implements Comparable<Point> {
	public int x;
	public int h;
	
	public Point(int x, int h) {
		super();
		this.x = x;
		this.h = h;
	}

	@Override
	public int compareTo(Point o) {
		if (x == o.x) {
			return h - o.h;
		}
		
		return x - o.x;
	}

	@Override
	public String toString() {
		return "(" + x + ", " + h + ")";
	}
	
}
