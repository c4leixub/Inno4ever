package com.microsoft.skyline;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class Solution {

	public static List<Point> getSkyline(List<Coordinate> coordinates) {
		List<Point> result = new ArrayList<Point>();
		
		// Step 1: convert to Point (x, y) and sort by x,
		// x == start => y = height, x == end => y = -height
		List<Point> pts = new ArrayList<Point>();
		for (Coordinate c : coordinates) {
			pts.add(new Point(c.start, c.height));
			pts.add(new Point(c.end, -1 * c.height));
		}		
		Collections.sort(pts);
	
		// Step 2:
		PriorityQueue<Integer> queue = new PriorityQueue<Integer>(
				new Comparator<Integer>() {
					public int compare(Integer o1, Integer o2) {
						return o2 - o1;
					}	
				});
		for (Point p : pts) {
			if (p.h > 0) {
				queue.add(p.h);
			} else {
				queue.remove(-1 * p.h);
			}
			
			Point np = new Point(p.x, p.h);
			if (queue.size() == 0) {
				np.h = 0;
			} else {
				np.h = queue.peek();
			}
			result.add(np);
		}
		
		// Step 3 merge points with the same h
		for (int i = 0; i < result.size() - 1; i++) {
			Point p1 = result.get(i);
			Point p2 = result.get(i+1);
			if (p1.h == p2.h) {
				result.remove(p2);
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		List<Coordinate> coordinates = new ArrayList<Coordinate>();
		coordinates.add(new Coordinate(2, 9, 10));
		coordinates.add(new Coordinate(3, 7, 15));
		coordinates.add(new Coordinate(5, 12, 12));
		coordinates.add(new Coordinate(15, 20, 10));
		coordinates.add(new Coordinate(19, 24, 8));
		
		System.out.println(getSkyline(coordinates));
		
		
	}
}
