package com.microsoft.singlelink;

import java.util.HashSet;
import java.util.Set;

/**
 * Input: two linked lists that have some duplicate nodes 
the list node contains a student's info: name, telephone, address. duplication exist if the same name and phone number appears in two different lists or repeat more than ones in the same list. 
Output: one lists that contains unique elements, duplications should be removed.
 * @author dij052
 *
 */
public class RemoveDuplicate {
	
	private class PNode {
		public String name;
		public String phone;
		public String address;
		public PNode next;
	}
	
	public static PNode removeDuplicate(PNode head1, PNode head2) {
		
		Set<String> s = new HashSet<String>();
		PNode rHead = null;
		PNode cur = null;
		
		PNode p = head1;
		PNode q = head2;
		
		while (p != null) {
			if (!s.contains(p.name+"|"+p.phone)) {
				s.add(p.name+"|"+p.phone);
				
				if (rHead == null) {
					rHead = p;
					cur = p;
				} else {
					cur.next = p;
					cur = cur.next;
				}
			}
			p = p.next;
		}
		
		while (q != null) {
			if (!s.contains(q.name+"|"+q.phone)) {
				s.add(q.name+"|"+q.phone);
				
				if (rHead == null) {
					rHead = q;
					cur = q;
				} else {
					cur.next = q;
					cur = cur.next;
				}
			}
			q = q.next;
		}
		
		
		return rHead;
	}

}
