package com.microsoft.singlelink;

import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

import com.microsoft.node.ListNode;

public class MergeTwoLinkedList {

	public ListNode mergeKLists(ListNode[] lists) {
		if (lists.length == 0) return null;
		
		PriorityQueue<ListNode> minHeap = new PriorityQueue<ListNode>(lists.length, 
				new Comparator<ListNode>() {
					@Override
					public int compare(ListNode o1, ListNode o2) {
						return o1.val - o2.val;
					}
			
		});
		HashMap<ListNode, Integer> map = new HashMap<ListNode, Integer>();
				
		ListNode dump = new ListNode(0);
		ListNode p = dump;
		for (int i = 0; i < lists.length; i++) {
			if (lists[i] != null) {
				minHeap.add(lists[i]);
				map.put(lists[i], i);
			}
		}
		
		ListNode next;
		while (!minHeap.isEmpty()) {
			next = minHeap.poll();
			int from = map.get(next);
			
			p.next = new ListNode(next.val);
			p = p.next;
			
			lists[from] = lists[from].next;
			if (lists[from] != null) {
				minHeap.add(lists[from]);
				map.put(lists[from], from);
			}
		}
		
		return dump.next;
    }
	
}
