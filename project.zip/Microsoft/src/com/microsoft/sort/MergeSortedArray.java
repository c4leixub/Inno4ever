package com.microsoft.sort;

public class MergeSortedArray {

	/*
	 * Given two sorted integer arrays A and B, merge B into A as one sorted array.
	 * A has m element, A[m]...A[m+n] are empty, and n is the length of B
	 * 
	 */
	public void merge(int A[], int m, int B[], int n) {
		if (n == 0) return;
		
		int index = m + n - 1;
		while (m > 0 && n > 0) {
			// compare elements from the end to front
			if (A[m - 1] > B[n - 1]) {
				A[index] = A[m - 1];
				m--;
			} else {
				A[index] = B[n - 1];
				n--;
			}
			index--;
		}
		
		while (n > 0) {
			A[index] = B[n - 1];
			n--;
			index--;
		}
	}

}
