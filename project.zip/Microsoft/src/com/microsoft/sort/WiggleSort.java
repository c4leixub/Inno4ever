package com.microsoft.sort;

import java.util.Arrays;

import com.microsoft.array.Utils;

/**
 * Given an unsorted array of int, re-order s.t
 * A[0] <= A[1] => A[2] <= A[3] => A[4]
 */
public class WiggleSort {
	
	// O(nlogn) solution
	public static void wiggleSort(int[] A) {
		Arrays.sort(A);	// sort the array first O(nlogn)
		
		// swap each pair start from (A[1], A[2])
		for (int i = 2; i < A.length; i += 2) {
			int tmp = A[i];
			A[i] = A[i-1];
			A[i-1] = tmp;
		}
	}
	
	/* O(n) solution
	 * The array is wiggle, the criteria is 
	 * 	if i is odd, then A[i-1] <= A[i]
	 *  if i is even, then A[i-1] >= A[i]
	 *  
	 * Start from i=1, if i is odd and A[i-1] > A[i],
	 * then we swap(A[i-1],A[i]). Similar when i is even.
	 */
	public static void wiggleSortOpt(int[] A) {
		for (int i = 1; i < A.length; i++) {
			if ((i % 2 == 1 && A[i-1] > A[i])
					|| (i % 2 == 0 && A[i-1] < A[i])) {
				int tmp = A[i];
				A[i] = A[i-1];
				A[i-1] = tmp;
			}
		}
	}
	
	public static void main(String[] args) {
		int[] A = new int[] {3, 5, 2, 1, 6, 4};
		wiggleSort(A);
		Utils.printIntArray(A);
		A = new int[] {3, 5, 2, 1, 6, 4};
		wiggleSortOpt(A);
		Utils.printIntArray(A);
	}
}
