package com.microsoft.permutation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class LetterCombinationsOfPhoneNumber {
    
    private static HashMap<Character, String> digitToLettersMap 
    												= new HashMap<Character, String>();
    static {
        digitToLettersMap.put('0', "");
        digitToLettersMap.put('1', "");
        digitToLettersMap.put('2', "abc");
        digitToLettersMap.put('3', "def");
        digitToLettersMap.put('4', "ghi");
        digitToLettersMap.put('5', "jkl");
        digitToLettersMap.put('6', "mno");
        digitToLettersMap.put('7', "pqrs");
        digitToLettersMap.put('8', "tuv");
        digitToLettersMap.put('9', "wxyz");
    };
    
    public static List<String> letterCombinations(String digits) {
    		List<String> res = new ArrayList<String>();
    		res.add("");
    		letterCombinationsHelper(res, digits);
    		if (res.size() == 1) {
    			res.clear();
    		}
    		return res;
    }
    
    private static void letterCombinationsHelper(List<String> res, String digits) {
    		if (digits.isEmpty()) return;
    	
    		String letters = digitToLettersMap.get(digits.charAt(0));
    		List<String> tmp = new ArrayList<String>();
    		for (String s : res) {
    			for (char c : letters.toCharArray()) {
    				tmp.add(s+c);
    			}
    		}
    		res.clear();
    		res.addAll(tmp);
    		letterCombinationsHelper(res, digits.substring(1));
    }
    
    public static void main(String[] args) {
    		System.out.println(letterCombinations("23"));
    		
    		int[] a = new int[] {1,2,3};
    		String[] s = new String[] {"","",""};
    		
    		test(a);
    		test(s);
    		
    		for (int i : a) {
    			System.out.print(i + ",");
    		}
    		System.out.println();
    		for (String st : s) {
    			System.out.print(st + ",");
    		}
    }
    
    public static void test(int[] a) {
    		a[1] = 10;
    }
    
    public static void test(String[] a) {
		a[1] = "abc";
    }
}


