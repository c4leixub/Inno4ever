package com.microsoft.datastructure;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

public class LRUCache {
	
	private Hashtable<Object, Object> cache;
	private List<Object> usedKeys;
	private int capacity;
	
	public LRUCache(int capacity) {
		cache = new Hashtable<Object, Object>();
		this.capacity = capacity;
		usedKeys = new ArrayList<Object>(this.capacity);
	}
	
	public Object get(Object key) {
		if (cache.containsKey(key)) {
			usedKeys.remove(key);
			usedKeys.add(0, key);
			return cache.get(key);
		} else {
			return null;
		}
	}
	
	public void set(Object key, Object value) {
		if (cache.containsKey(key)) {
			usedKeys.remove(key);
			usedKeys.add(0, key);
			cache.put(key, value);
			return;
		} 
		
		if (usedKeys.size() == this.capacity) {
			// get the last key and remove from cache and usedKeys
			Object removeKey = usedKeys.get(capacity-1);
			usedKeys.remove(capacity-1);
			cache.remove(removeKey);
		}
		usedKeys.add(0, key);
		cache.put(key, value);
	}
}
