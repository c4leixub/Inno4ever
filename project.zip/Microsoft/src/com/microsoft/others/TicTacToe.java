package com.microsoft.others;

public class TicTacToe {

	private char[][] board;
	private char currentPlayer = PLAYER_ONE;

	private static int SIZE = 3;
	private static char PLAYER_ONE = 'X';
	private static char PLAYER_TWO = 'O';
	private static String THREE_X = "XXX";
	private static String THREE_O = "OOO";

	public TicTacToe() {
		board = new char[SIZE][SIZE];
	}

	public boolean play(int i, int j) {
		if (board[i][j] != PLAYER_ONE && board[i][j] != PLAYER_TWO) {
			board[i][j] = currentPlayer;
		}
		return false;
	}

	public void swithPlayer() {
		currentPlayer = currentPlayer == PLAYER_ONE ? PLAYER_TWO : PLAYER_ONE;
	}

	public boolean playToWin(int i, int j) throws InvalidMoveException {
		if (!play(i, j))
			throw new InvalidMoveException();

		if (i == 1 && j == 1) { 
			boolean result = true;	// check diagonal '\'
			for (int k = 0; k < SIZE; k++) {
				result = result && board[k][k] == currentPlayer;
			}
			if (result)
				return result;
			
			result = true;	// check diagonal '/'
			for (int k = 0; k < SIZE; k++) {
				result = result && board[k][SIZE-k-1] == currentPlayer;
			}
			if (result)
				return result;
		}

		boolean result = true;
		for (int k = 0; k < SIZE; k++) {
			result = result && board[k][j] == currentPlayer;
		}
		if (result)
			return result;

		result = true;
		for (int k = 0; k < SIZE; k++) {
			result = result && board[i][k] == currentPlayer;
		}
		if (result)
			return result;

		return false;
	}

	public boolean hasWon() {
		String tmp = "";
		for (int k = 0; k < SIZE; k++) {
			tmp += board[k][k];
		}
		if (tmp.equals(THREE_X) || tmp.equals(THREE_O))
			return true;
		
		for (int k = 0; k < SIZE; k++) {
			tmp += board[k][SIZE-k-1];
		}
		if (tmp.equals(THREE_X) || tmp.equals(THREE_O))
			return true;


		for (int i = 0; i < SIZE; i++) {
			tmp = "";
			for (int j = 0; j < SIZE; j++) {
				tmp += board[i][j];
			}
			if (tmp.equals(THREE_X) || tmp.equals(THREE_O))
				return true;
		}

		for (int j = 0; j < SIZE; j++) {
			tmp = "";
			for (int i = 0; i < SIZE; i++) {
				tmp += board[i][j];
			}
			if (tmp.equals(THREE_X) || tmp.equals(THREE_O))
				return true;
		}
		
		return false;
	}

	private class InvalidMoveException extends Exception {
		public InvalidMoveException() {
			super("Invalid move, the tile is occupied. Try a different tile.");
		}
	}

}
