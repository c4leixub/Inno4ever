package com.microsoft.others;

public class DivideInteger {
	
	// a / b
	public static int divide(int a, int b) {
		if (b == 0) {
			// throw exception for divide 0
			throw new ArithmeticException("/ by zero");
		}
		
		if (a < b) {
			return 0;
		}
		
		int res = 0;
		while (a >= b) {
			a = a - b;
			res++;
		}
		
		return res;
	}
	
	public static void main(String[] args) {
		System.out.println(divide(4,5));
		System.out.println(divide(10,5));
		System.out.println(divide(0,10));
		System.out.println(divide(10, 10));
		System.out.println(divide(10, 3));
		divide(10, 0);
	}
}
