package com.microsoft.others;

import java.util.AbstractMap;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class TwoSumArray {

	public static List<SimpleEntry<Integer, Integer>> twoSum(int[] arr, int x) {
		
		List<SimpleEntry<Integer, Integer>> result = new ArrayList<SimpleEntry<Integer, Integer>>();
		
		HashSet<Integer> s = new HashSet<Integer>();
		for (int i = 0; i < arr.length; i++) {
			if (!s.contains(x-arr[i])) {
				s.add(arr[i]);
			} else {
				result.add(new SimpleEntry<Integer, Integer>(arr[i], x-arr[i]));
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		int[] arr = {1,2,3,0,5,2};
		
		
		System.out.println(twoSum(arr, 4));
	}
}
