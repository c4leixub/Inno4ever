package com.microsoft.others;

public class StringToInt {

	private static String regex = "^(0|[-]?[1-9][0-9]*)$";
	
	public static int convert(String s) {
		isValid(s);
		
		boolean isNegative = s.charAt(0) == '-';
		if (isNegative) s = s.substring(1);
		int r = 0;
		while (!s.isEmpty()) {
			r += (s.charAt(0) - 48) * (int) Math.pow(10, s.length()-1);
			s = s.substring(1);
		}
		
		return !isNegative ? r : 0 - r;
		
	}
	
	private static void isValid(String s) {
		if (!s.matches(regex)) {
			throw new NumberFormatException("Invalid number format");
		}
	}
	
	public static void main(String[] args) {
		System.out.println(convert("1234"));
		System.out.println(convert("-1234"));
		
		String regex = "^(0|[-]?[1-9][0-9]*)$";
		
		System.out.println("0".matches(regex));
		System.out.println("-0".matches(regex));
		System.out.println("000".matches(regex));
		System.out.println("1".matches(regex));
		System.out.println("12".matches(regex));
		System.out.println("01".matches(regex));
		System.out.println("01sdf".matches(regex));
		System.out.println("-1".matches(regex));
		
	}
}
