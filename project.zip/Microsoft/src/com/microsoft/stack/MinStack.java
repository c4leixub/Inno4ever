package com.microsoft.stack;

import java.util.Stack;

public class MinStack {

	private Stack<Integer> mins = new Stack<Integer>();
	private Stack<Integer> stack = new Stack<Integer>();
	
	public Integer pop() {
		if (stack.peek() == mins.peek()) {
			mins.pop();
		}
		return stack.pop();
	}
	
	public void push(Integer e) {
		stack.push(e);
		if (e < mins.peek()) {
			mins.push(e);
		}
	}
	
	public Integer min() {
		return mins.peek();
	}
	
	public Integer peek() {
		return stack.peek();
	}
}
