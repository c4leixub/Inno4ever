package com.microsoft.tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import com.microsoft.node.TreeNode;

public class SerializeDeserializeBinaryTree {
	public static String serialize(TreeNode root) {
		if (root == null) return "[]";

		List<Integer> st = new ArrayList<Integer>();
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		queue.add(root);

		while (!queue.isEmpty()) {
			TreeNode node = queue.poll();
			if (node != null) {
				st.add(node.val);
				queue.add(node.left);
				queue.add(node.right);
			} else {
				st.add(null);
			}
			
		}
		
		int last = st.size()-1;
		while (st.get(last) == null) {
			st.remove(last);
			last--;
		}
		return st.toString();
	}

	// Decodes your encoded data to tree.
	public static TreeNode deserialize(String data) {
		List<Integer> st = toValList(data);
		if (st.isEmpty()) return null;
		
		
		TreeNode root = new TreeNode(st.get(0));
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		queue.add(root);
		st.remove(0);
		
		boolean[] flags = new boolean[2];
		while (!st.isEmpty()) {
			Integer e = st.get(0);
			TreeNode node = queue.peek();
			if (flags[0] && flags[1]) {
				queue.poll();
				node = queue.peek();
				
				flags[0] = false;
				flags[1] = false;
			}
			
			TreeNode n = e != null ? new TreeNode(e) : null;
			if (!flags[0]) {
				node.left = n;
				if (e != null) queue.add(node.left);
				flags[0] = true;
			} else if (!flags[1]) {
				node.right = n;
				if (e != null) queue.add(node.right);
				flags[1] = true;
			}
			
			st.remove(0);
		}
		
		return root;
		
	}
	
	private static List<Integer> toValList(String data) {
		List<Integer> st = new ArrayList<Integer>();
		String[] nodeVal = data.substring(1, data.length() - 1).split(", ");
		if (nodeVal.length == 1 && nodeVal[0].equals("")) return st;
		
		for (String s : nodeVal) {
			if ("null".equals(s)) {
				st.add(null);
			} else {
				st.add(Integer.parseInt(s));
			}
		}
		return st;
	}
	
	public static void main(String[] args) {
		TreeNode nullCase = deserialize("[]");
		
		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(2);
		root.right = new TreeNode(3);
		root.left.left = new TreeNode(6);
		root.right.left = new TreeNode(4);
		root.right.right = new TreeNode(5);
		
		String s = serialize(root);
		System.out.println(s);
		
		TreeNode loot = deserialize(s);
		System.out.print(loot.val + ", ");
		System.out.print(loot.left.val + ", ");
		System.out.print(loot.right.val + ", ");
		
		System.out.print(loot.left.left + ", ");
		System.out.print(loot.left.right + ", ");
		
		System.out.print(loot.right.left.val + ", ");
		System.out.print(loot.right.right.val + ", ");
		
	}
}
