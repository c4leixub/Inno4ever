package com.microsoft.tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

import com.microsoft.node.TreeNode;

public class ZigZagTranversal {

	public List<List<Integer>> zigzagLevelOrder(TreeNode root) {
		List<List<Integer>> result = new ArrayList<List<Integer>>();
		
		boolean flag = true;
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		Queue<TreeNode> queueR = new LinkedList<TreeNode>();
		queue.add(root);
		
		List<Integer> current = new ArrayList<Integer>();
		while(!queue.isEmpty() && !queueR.isEmpty()) {
			TreeNode node; 
			if (flag) {
				node = queue.poll();
				queueR.add(node.left);
				queueR.add(node.right);
				current.add(node.val);
				if (queue.isEmpty()) {
					flag = false;
					result.add(current);
					current = new LinkedList<Integer>();
				}
			} else {
				node = queueR.poll();
				queue.add(node.left);
				queue.add(node.right);
				current.add(0, node.val);
				if (queueR.isEmpty()) {
					flag = true;
					result.add(current);
					current = new ArrayList<Integer>();
				}
			}
		}
		
		return result;
    }
}
