package com.microsoft.tree;

public class Node {
	public int value;
	public Node left;
	public Node right;
	
	public Node parent;
	public Node next;
}
