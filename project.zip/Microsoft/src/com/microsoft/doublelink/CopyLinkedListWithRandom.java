package com.microsoft.doublelink;

import java.util.HashMap;

public class CopyLinkedListWithRandom {

	public static class RNode {
		public int value;
		public RNode next;
		public RNode prev;
		public RNode random;
	}

	public static RNode copy(RNode head) {

		if (head == null) return null;
		
		// key: old node, value : new node
		// let x be a node, y be the random of x, after copy we get x'
		// and because we have a map, we can determine x -> x'
		// to connect x' with y', use x'.random = map.get(x.random = y) = y'
		HashMap<RNode, RNode> m = new HashMap<RNode, RNode>();

		RNode nHead = new RNode();
		nHead.value = head.value;
		m.put(head, nHead);

		RNode p = head.next;

		RNode q_prev = null;
		RNode q = nHead;

		while (p != null) {
			q.next = new RNode();
			q.next.value = p.value;
			
			q_prev = q;
			q = q.next;
			q.prev = q_prev;
			
			p = p.next;
		}

		p = head;
		q = nHead;
		while (p != null) {
			if (p.random != null) {
				q.random = m.get(p.random);
			}

			p = p.next;
			q = q.next;
		}
		
		return nHead;
	}
}
