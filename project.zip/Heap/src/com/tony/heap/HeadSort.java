package com.tony.heap;

public class HeadSort {

	public static void sort(int[] array) {
	
		Heap heap = new Heap(array.length);
		
		int j = 0;
		for(j=0; j < array.length; j++)
			heap.insert( array[j] );
		
		for(j=0; j < array.length; j++)
			array[j] = heap.remove().getKey();
	}
	
	public static void main(String[] args) {
		
		int[] keys = new int[] { 100, 30, 50, 80, 20, 40};
		sort(keys);
		for(int j=0; j < keys.length; j++) {
			System.out.print(keys[j] + " ");
		}
		
	}

}
