package com.tony.heap;

/*
 * array to heap/tree conversion : x is index start from 0
 * 
 * parent (x-1)/2
 * left child 2 * x + 1
 * right child 2 * x + 2
 *
 */
public class Heap {

	private Node[] heapArray;
	private int maxSize;
	private int currentSize;

	public Heap(int maxSize) {
		this.maxSize = maxSize;
		heapArray = new Node[maxSize];
		this.currentSize = 0;
	}

	public boolean isEmpty() {
		return currentSize == 0;
	}

	public boolean insert(int key) {
		if (currentSize == maxSize) {
			return false;
		}
		Node newNode = new Node(key);
		heapArray[currentSize] = newNode;
		trickleUp(currentSize);
		currentSize++;
		return true;
	}

	private void trickleUp(int index) {
		int parent = (index - 1) / 2;
		
		Node temp = heapArray[index];	// save my newly insert key
		while (index > 0 && heapArray[parent].getKey() < temp.getKey()) {
			heapArray[index] = heapArray[parent];
			
			index = parent;
			parent = (index - 1) / 2;	
		}
		heapArray[index] = temp;
		
//		while (index != 0 && heapArray[parent].getKey() < heapArray[index].getKey()) {
//			
//			Node temp = heapArray[index];
//			heapArray[index] = heapArray[(index - 1) / 2];
//			heapArray[(index - 1) / 2] = temp;
//			
//			index = parent;
//			parent = (index - 1) / 2;	
//		}
	}
	
	private void trickleUpRecursive(int index) {
		if (index == 0 || heapArray[index].getKey() < heapArray[(index - 1) / 2].getKey()) {
			return;
		} else {
			Node temp = heapArray[index];
			heapArray[index] = heapArray[(index - 1) / 2];
			heapArray[(index - 1) / 2] = temp;
			
			trickleUpRecursive((index - 1) / 2);
		}
	}
	
	/*
	 * Only remove the root/first element
	 */
	public Node remove() {
		Node root = heapArray[0];
		heapArray[0] = heapArray[currentSize - 1];
		//heapArray[currentSize - 1] = null;
		currentSize--;
		trickleDown(0);
		return root;
	}
	
	private void trickleDown(int index) {
		int leftChild = 2 * index + 1;
		int rightChild = leftChild + 1; // = 2 * index = 2;
		
		Node temp = heapArray[index];
		while(leftChild <= currentSize) {	// at least one child  
			
			int largerChild;
			if (rightChild < currentSize 	// (rightChild exists?)
					&& heapArray[leftChild].getKey() < heapArray[rightChild].getKey()) {
				largerChild = rightChild;
			} else {
				largerChild = leftChild;
			}
			
			// condition to stop
			if(temp.getKey() >= heapArray[largerChild].getKey())
				break;
			
			// shift child up
			heapArray[index] = heapArray[largerChild];
			index = largerChild;
			leftChild = 2 * index + 1;
			rightChild = leftChild + 1; // = 2 * index = 2;
			
		}
		
		heapArray[index] = temp;
	}
	
	private void trickleDownRecursive(int index) {
		
		int leftChild = 2 * index + 1;
		int rightChild = leftChild + 1; // = 2 * index = 2;
		if (leftChild <= currentSize) {
			int largerChild = (heapArray[rightChild] == null
					|| heapArray[rightChild].getKey() < heapArray[leftChild].getKey()) 
				? leftChild : rightChild;
			
			Node temp = heapArray[index];
			if(temp.getKey() >= heapArray[largerChild].getKey()) {
				heapArray[index] = heapArray[largerChild];
				heapArray[largerChild] = temp;
				
				trickleDownRecursive(largerChild);
			}
		}	
	}
	
	public boolean change(int index, int newKey) {
		if (index < 0 || index >= currentSize) {
			return false;
		}
		
		int oldKey = heapArray[index].getKey();
		heapArray[index].setKey(newKey);
		
		if (newKey > oldKey) {
			this.trickleUp(index);
		} else if (newKey < oldKey) {
			this.trickleDown(index);
		}
		
		return true;
	}
	
	public void displayHeap() {
		System.out.print("heapArray: ");
		for (int i = 0; i != currentSize; i++) {
			System.out.print(" " + heapArray[i].getKey());
		}
		System.out.println();
	}

}
