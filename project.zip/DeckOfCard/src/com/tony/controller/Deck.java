package com.tony.controller;

import com.tony.domain.Card;

public class Deck {

	private Card[] cards;
	private int nextAvailiableCard;
	
	public void shuffle() {
		// an algorithm random place the card
		// in different place of the array
		
		nextAvailiableCard = 0;
	}
	
	public Card nextCard() {
		Card c = cards[nextAvailiableCard];
		nextAvailiableCard++;
		return c;
	}
}
