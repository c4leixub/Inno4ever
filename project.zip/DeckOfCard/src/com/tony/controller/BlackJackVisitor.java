package com.tony.controller;

import java.util.List;

import com.tony.domain.Card;
import com.tony.domain.Hand;

public class BlackJackVisitor implements CardGameVisitor {

	private boolean aceAsEleven;
	
	public BlackJackVisitor(boolean aceAsEleven) {
		this.aceAsEleven = aceAsEleven;
	}
	
	@Override
	public int visit(Hand hand) {
		List<Card> cards = hand.getCards();
		
		int total = 0;
		for (Card card : cards) {
			if (card.getFaceValue() == 1 && aceAsEleven) {
				total += 11;
			} else if (card.getFaceValue() >= 10) {
				total += 10;
			} else {
				total += card.getFaceValue();
			}
		}
		
		return total;
	}

}
