package com.tony.controller;

import com.tony.domain.Hand;

public interface CardGameVisitor {
	
	public int visit(Hand hand);

}
