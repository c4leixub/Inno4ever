package com.tony.domain;

import java.util.ArrayList;
import java.util.List;

public abstract class Hand {

	private List<Card> cards;

	public Hand() {
		cards = new ArrayList<Card>();
	}
		
	public List<Card> getCards() {
		return cards;
	}

	public void addCard(Card c) {
		cards.add(c);
	}
}
