package com.tony.domain;

public class Card {

	protected int faceValue;
	protected int type;
	
	public Card(int faceValue, int type) {
		super();
		this.faceValue = faceValue;
		this.type = type;
	}
	
	public int getFaceValue() {
		return faceValue;
	}
	public int getType() {
		return type;
	}

}
