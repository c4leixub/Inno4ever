package com.tony.Linkedin;

public class Stepwise2DArraySearch {

	public static boolean search(int[][] A, int t) {
		
		int rows = A.length;
		if (rows == 0)	return false;
		
		int cols = A[0].length;
		if (cols == 0) return false;
		
		if(t < A[0][0] || t > A[rows - 1][cols - 1]) return false;
		
		int i = 0;
		int j = cols - 1;
		while (i < rows && j >= 0) {
			if (A[i][j] < t) {
				i++;
			} else if (A[i][j] > t) {
				j--;
			} else {
				return true;
			}
		}
		
		return false;
	}
	
	public static void main(String[] args) {
		int[] a = new int[0];
	}

}
