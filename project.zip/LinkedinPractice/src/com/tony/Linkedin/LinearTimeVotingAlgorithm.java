package com.tony.Linkedin;

public class LinearTimeVotingAlgorithm {

	public static Integer appearHalfTime(int[] A) {
		int candidate = Integer.MIN_VALUE;
		int vote = 0;
		for (int i : A) {
			if (i == candidate) {
				vote++;
			} else {
				vote--;
			}
			
			if (vote <= 0) {
				candidate = i;
				vote = 1;
			}
		}
		
		
		vote = 0;
		for (int i : A) {
			if (i == candidate) vote++;
		}
		if (vote > A.length / 2) return candidate;
		
		return null;
	}
	
	public static Integer appearThirdTime(int[] A) {
		int first = Integer.MIN_VALUE; 	// the number with the top votes
        int firstVote = 0; 				// the top votes
        
        int second = Integer.MIN_VALUE; // the number with the second top votes
        int secondVote = 0; 			// the second top votes
        
        for (int i : A) {
        	if (i == first) {
        		firstVote++;
        	} else if (i == second) {
        		secondVote++;
        		
        		if (secondVote > firstVote) {
        			int t = firstVote;
        			firstVote = secondVote;
        			secondVote = t;
        			
        			t = first;
        			first = second;
        			second = t;
        		}
        	} else if (i != first && i != second) {
        		firstVote--;
        		secondVote--;
        	}
        	
        	if (firstVote <= 0) {
        		first = i;
        		firstVote = 1;
        	} else if (secondVote <= 0 && i != first) {
        		second = i;
        		secondVote = 1;
        	}
        }
        
        firstVote = 0; 
        secondVote = 0; 
		for (int i : A) {
			if (i == first) firstVote++;
			if (i == second) secondVote++;
		}
		if (firstVote > A.length / 3) return first;
		if (secondVote > A.length / 3) return second;
		
		return null;
		
	}
	
	
	public static void main(String[] args) {
		System.out.println(appearHalfTime(new int[] {1,1,1,3,3,2,2,3,3,3,2,3,3}));
		System.out.println(appearHalfTime(new int[] {1, 3, 3, 1, 2}));
		
		System.out.println(appearThirdTime(new int[] {3, 3, 1, 1, 1, 2, 2}));
	}

}
