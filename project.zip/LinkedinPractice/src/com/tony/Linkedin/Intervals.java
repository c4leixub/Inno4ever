package com.tony.Linkedin;

import java.util.ArrayList;
import java.util.List;

public class Intervals {

	public class Interval implements Comparable<Interval>{
		public int start;
		public int end;
		public Interval(int s, int e) {
			this.start = s;
			this.end = e;
		}
		public String toString() {
			return "(" + start + "," + end + ")";
		}
		
		@Override
		public int compareTo(Interval o) {
			if (this.start < o.start) {
				return -1;
			} else if (this.start > o.start) {
				return 1;
			}
			
			return 0;
		}
		
		public boolean equals(Interval i) {
			return start == i.start && end == i.end;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			
			Interval other = (Interval) obj;
			if (start != other.start || end != other.end)
				return false;
			
			return true;
		}
	}
	
	private List<Interval> intervals = new ArrayList<Interval>();
	
	/*
	 * TODO: Merge case didn't get handle
	 */
	public void addInterval(int s, int e) {
		
		Interval a = getInterval(s);
		Interval b = getInterval(e);
		
		if (a != null && b != null) {
			if (a.equals(b)) return;
			
			intervals.add(new Interval(a.start, b.end));
		} else if (a != null) {
			intervals.add(new Interval(a.start, e));
		} else if (b != null) {
			intervals.add(new Interval(s, b.end));
		} else {
			
			Interval t = null;
			for (Interval interval : intervals) {
				if (s <= interval.end && interval.end <= e) {
					t = interval;
				}
			}
			
			if (t != null) intervals.remove(t);
			intervals.add(new Interval(s, e));
		}
		
		if (a != null) intervals.remove(a);
		if (b != null) intervals.remove(b);
		System.out.println(this.intervals);
	}
	
	private Interval getInterval(int i) {
		for (Interval interval : intervals) {
			if (interval.start <= i && i <= interval.end) {
				return interval;
			}
		}
		
		return null;
	}
	
	public int getTotalCoverLength() {
		int result = 0;
		for (Interval interval : intervals) {
			result += (interval.end - interval.start);
		}
		return result;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Intervals obj = new Intervals();
		obj.addInterval(3, 6);
		obj.addInterval(2, 7);
		System.out.println(obj.getTotalCoverLength());
		
		obj = new Intervals();
		obj.addInterval(1, 3);
		obj.addInterval(5, 7);
		obj.addInterval(2, 4);
		System.out.println(obj.getTotalCoverLength());
		
		obj = new Intervals();
		obj.addInterval(1, 3);
		obj.addInterval(8, 9);
		obj.addInterval(5, 7);
		obj.addInterval(2, 5);
		System.out.println(obj.getTotalCoverLength());
		
		obj = new Intervals();
		obj.addInterval(1, 3);
		obj.addInterval(8, 9);
		obj.addInterval(5, 7);
		obj.addInterval(4, 6);
		System.out.println(obj.getTotalCoverLength());
		
		obj = new Intervals();
		obj.addInterval(1, 3);
		obj.addInterval(5, 7);
		obj.addInterval(3, 6);
		System.out.println(obj.getTotalCoverLength());
	}

}
