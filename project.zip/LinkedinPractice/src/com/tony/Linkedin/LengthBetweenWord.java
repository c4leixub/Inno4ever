package com.tony.Linkedin;

import java.util.StringTokenizer;

public class LengthBetweenWord {

	/*
	 * 	Find minimum distance between two words (order preserved) in a big string. 
		For e.g 1. "hello how are you" - distance between "hello" and "you" is 3. 
		e.g 2. "hello how are hello you" - distance is 1 
		e.g 3. "you are hello" - distance is -1. Order of "hello" and "you" should be preserved. 
		e.g 4. "hello how are hello" - distance is -1 since "you" didnt occur even once.
	 */
	public static int distance(String str, String w1, String w2) {
		if (str.isEmpty() || w1.isEmpty() || w2.isEmpty()) {
            return -1;
        }
		if (w1.equals(w2)) {
            return 0;
        }
		
		StringTokenizer st = new StringTokenizer(str);
		String tk;
		boolean foundStart = false;
		boolean foundEnd = false;
		int distance = -1;
		while (st.hasMoreTokens()) {
			tk = st.nextToken();
			if (tk.equals(w1)) {
				distance = 0;
				foundStart = true;
			} else if (tk.equals(w2)) {
				if (!foundStart) return -1;
				distance++;
				foundEnd = true;
				break;
			} else {
				if (distance >= 0) distance++;
			}
		}
		
		if (!foundEnd) return -1;
		
		return distance;
	}

}
