package com.tony.Linkedin;

public class CheckStringNumber {

	public static void main(String[] s) {
		System.out.println("123"+ " " + isNumber("123"));
		System.out.println("-1"+ " " + isNumber("-1"));
		System.out.println("+1"+ " " + isNumber("+1"));
		System.out.println("+1.2"+ " " + isNumber("+1.2"));
		System.out.println("-1.3"+ " " + isNumber("-1.3"));
		System.out.println("1.3"+ " " + isNumber("1.3"));
		
		System.out.println(".3123" + " " + isNumber(".3123"));
		System.out.println("+.3123" + " " + isNumber("+.3123"));
		System.out.println("+" + " " + isNumber("+"));
		System.out.println("." + " " + isNumber("."));
		
	}
	
	public static boolean isNumber(String s) {
		
		if (s == null) return false;
		if (s.length() == 0) return false;
		
		int start = 0;
		boolean foundPoint = false;
		if (s.length() > 0) {
			char sign = s.charAt(0);
			if ((sign == '-' || sign == '+') && s.length() > 1) {
				start = 1;
			}
		}
		
		for (int i = start; i != s.length(); i++) {
			if (s.charAt(i) == '.') {
				if (foundPoint) {
					return false;
				} else {
					foundPoint = true;
					if (i == start) return false;
				}
			} else {
				if (s.charAt(i) < 48 || s.charAt(i) > 57) return false;
			}
			
		}
		
		return true;
	}

}
