package com.tony.Linkedin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
There are 2 sorted sets.Find the common elements of those sets 
e.g. 
A={1,2,3,4,5,6} 
B={5,6,7,8,9} 
o/p C={5,6} 

Complexity should ne 0(n+m) where n and m is the size of the first and second set respectively 
 */
public class FindArrayIntersectAndUnion {

	public List<Integer> intersect(int[] A, int[] B) {
		
		Arrays.sort(A);
		Arrays.sort(B);
		
		List<Integer> result = new ArrayList<Integer>();
		
		int i = 0;
		int j = 0;
		while (i != A.length && j != B.length) {
			
			if (A[i] < B[j]) i++;
			if (A[i] > B[j]) j++;
			
			if (A[i] == B[j]) {
				result.add(A[i]);
				i++;
				j++;
			}
		}
		
		return result;
	}
	
	public List<Integer> union(int[] A, int[] B) {
		
		Arrays.sort(A);	// O(nlogn)
		Arrays.sort(B);
		
		List<Integer> result = new ArrayList<Integer>();
		
		int i = 0;
		int j = 0;
		while (i != A.length && j != B.length) {
			if (A[i] < B[j]) {
				result.add(A[i]);
				i++;
			} else if (A[i] > B[j]) {
				result.add(B[j]);
				j++;
			} else {
				result.add(A[i]);
				i++;
				j++;
			}
		}
		
		while (i != A.length) {
			result.add(A[i]);
			i++;
		}
		while (j != B.length) {
			result.add(B[j]);
			j++;
		}
		
		return result;
	}

}
