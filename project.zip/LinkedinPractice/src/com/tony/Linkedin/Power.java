package com.tony.Linkedin;

public class Power {

	public static double pow(double d, int i) {
		if (i < 0)	return 1.0 / pow(d, 0 - i);
		if (i == 0) return 1.0;
		if (i == 1) return d;
		
		// return d * pow(d, i - 1);
		
		// O(log n) solution
		double result = pow(d, i / 2);
		result *= result;
		
		if (i % 2 == 1) {
			result *= d;
		}
		return result;	
	}
	
	public static void main(String args[]) {
//		System.out.println(pow(2.0, -4));
//		System.out.println(pow(2.0, -3));
//		System.out.println(pow(2.0, -2));
//		System.out.println(pow(2.0, -1));
//		System.out.println(pow(2.0, 0));
//		System.out.println(pow(2.0, 1));
//		System.out.println(pow(2.0, 2));
//		System.out.println(pow(2.0, 3));
//		System.out.println(pow(2.0, 4));
		
		System.out.println(pow(2.0, 3));
		System.out.println(-3%2);
		
	}

}
