package com.tony.Linkedin;

import java.util.StringTokenizer;

public class StringJustification {
	
	public static String justify(String str, int length, char c) {
		int charCount = 0;
		String[] strArray = str.split(" ");
		for (int i = 0; i != strArray.length; i++) {
			charCount += strArray[i].length();
		}
		
		int space = length - charCount; 
		String cs = "";
		int csLength = space % strArray.length == 0 ? space / strArray.length : space / strArray.length + 1;
		for(int i = 0; i != csLength; i++) {
			cs += c;
		}
		
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i != strArray.length && builder.length() < length; i++) {
			builder.append(strArray[i]);
			if (builder.length() + csLength < length) {
				builder.append(cs);
			} else {
				break;
			}
		}
		
		int b = length - builder.length();
		for (int i = 0; i < b; i++) {
			builder.append(c);
		}
		
		
		return builder.toString();
	}
	
	public static void main(String[] args) {
		String a = "hello world man";
		String b = justify(a, 48, '.');
		System.out.println(b);
		System.out.println(b.length());
	}

}
