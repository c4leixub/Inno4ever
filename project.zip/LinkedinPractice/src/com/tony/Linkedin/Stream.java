package com.tony.Linkedin;

import java.util.PriorityQueue;

public class Stream {

	private class Pair implements Comparable<Pair> {
		
		public int stream;
		public int value;
		
		public Pair(int stream, int value) {
			this.stream = stream;
			this.value = value;
		}
		
		@Override
		public int compareTo(Pair o) {
			if (value < o.value) {
				return -1;
			} else if (value > o.value) {
				return 1;
			}
			
			return 0;
		}
	}
	
	private Stream[] streams;
	private int[] stream;
	private int pos = 0;
	private PriorityQueue<Pair> queue = new PriorityQueue<Pair>();
	
	public Stream(Stream[] streams) {
		this.streams = streams;
		for (int i = 0; i != streams.length; i++) {
			if (streams[i].hasNext()) {
				queue.add(new Pair(i, streams[i].next()));
			}
		}
	}
	
	public boolean hasNext() {
		if (streams != null) return queue.isEmpty();
		
		return pos < stream.length;
	}
	
	public int next() {
		int value;
		if (streams != null) {
			
			Pair p = queue.remove();
			value = p.value;
			if (streams[p.stream].hasNext()) {
				queue.add(new Pair(p.stream, streams[p.stream].next()));
			}
			
			return value;
		}
		
		value = stream[pos];
		pos++;
		return value;
	}
	
	public static Stream merge(Stream[] streams) {
		return new Stream(streams);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
	}

}
