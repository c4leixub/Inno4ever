package com.tony.Linkedin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapIterator implements Iterator {

	private ArrayList<Object> values;
	private int pos;
	
	public HashMapIterator(HashMap map) {
		values = new ArrayList<Object>();
		insert(map);
		pos = 0;
	}
	
	private void insert(HashMap map) {
		Set keySet = map.keySet();
		for (Object key : keySet) {
			if (map.get(key) instanceof HashMap) {
				insert((HashMap) map.get(key));
			} else {
				values.add(map.get(key));
			}
		}
	}
	
	@Override
	public boolean hasNext() {
		return pos != values.size();
	}

	@Override
	public Object next() {
		Object o = values.get(pos);
		pos++;
		return o;
	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String args[]) {
	      // Create an array list
	      ArrayList al = new ArrayList();
	      // add elements to the array list
	      al.add("C");
	      al.add("A");
	      al.add("E");
	      al.add("B");
	      al.add("D");
	      al.add("F");

	      // Use iterator to display contents of al
	      System.out.print("Original contents of al: ");
	      Iterator itr = al.iterator();
	      
	      Object element = itr.next();
          System.out.print(element + " ");
	      
	      itr.remove();
	      
	      while(itr.hasNext()) {
	          element = itr.next();
	          System.out.print(element + " ");
	      }
	      
	      System.out.println(al);
	}

}
