package com.tony.Linkedin;

public class NextCharacter {

	/** 
	* Return the smallest character that is strictly larger than the search character, 
	* If no such character exists, return the smallest character in the array 
	* @param sortedStr : sorted list of letters, sorted in ascending order. 
	* @param c : character for which we are searching. 
	* Given the following inputs we expect the corresponding output: 
	* ['c', 'f', 'j', 'p', 'v'], 'a' => 'c' 
	* ['c', 'f', 'j', 'p', 'v'], 'c' => 'f' 
	* ['c', 'f', 'j', 'p', 'v'], 'k' => 'p' 
	* ['c', 'f', 'j', 'p', 'v'], 'z' => 'c' // The wrap around case 
	* ['c', 'f', 'k'], 'f' => 'k' 
	* ['c', 'f', 'k'], 'c' => 'f' 
	* ['c', 'f', 'k'], 'd' => 'f' 
	*/
	public static char nextChar(String sortedStr, char c) {
		
		if (sortedStr.length() == 0) return (Character) null;
		if (c == 'z') return sortedStr.charAt(0);
		
		for (int i = 0; i < sortedStr.length(); i++) {
			if (sortedStr.charAt(i) > c) {
				return sortedStr.charAt(i);
			}
		}
		
		return sortedStr.charAt(0);
	}
	
	public static char nextCharBinary(String sortedStr, char c) {
		
		if (sortedStr.length() == 0) return (Character) null;
		if (c == 'z') return sortedStr.charAt(0);
		
		char result = sortedStr.charAt(0);
		int i = 0, j = sortedStr.length() - 1;
		while (i <= j) {
			int m = (i+j) / 2;
			if (sortedStr.charAt(m) > c) {
				result = sortedStr.charAt(m);
				j = m - 1;
			} else if (sortedStr.charAt(m) < c) {
				i = m + 1;
			} else {
				if (m == sortedStr.length() - 1) {
					result = sortedStr.charAt(0);
				} else {
					result = sortedStr.charAt(m + 1);
				}
				break;
			}
		}
		
		return result;
	}

}
