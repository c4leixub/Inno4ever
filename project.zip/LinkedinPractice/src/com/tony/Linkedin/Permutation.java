package com.tony.Linkedin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Permutation {

	public static Set<List<Integer>> getPermutation(List<Integer> intList) {
		Set<List<Integer>> result = new HashSet<List<Integer>>();
		if (intList.size() == 0)
			return result;
		for (Integer i : intList) {
			List<Integer> newList = new ArrayList<Integer>();
			newList.add(i);
			result.add(newList);
		}

		for (int j = 1; j != intList.size(); j++) {
			Set<List<Integer>> newResult = new HashSet<List<Integer>>();
			for (List<Integer> list : result) {
				for (Integer i : intList) {
					if (!list.contains(i)) {
						List<Integer> newList = new ArrayList<Integer>(list);
						newList.add(i);
						newResult.add(newList);
						
						System.out.println("i: " + i + " newList: " + newList);
					}
				}
			}
			result = newResult;
			
			System.out.println("result: " + result);
		}

		return result;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer> newList = new ArrayList<Integer>();
		newList.add(1);
		newList.add(2);
		newList.add(3);
		//newList.add(4);
		System.out.println(getPermutation(newList));

	}

}
