package com.tony.Linkedin;

import java.util.Stack;

public class Celebrity {

	public static int getCelebrity(boolean[][] matrix) {
		Stack<Integer> s = new Stack<Integer>();
		for (int i = 0; i < matrix.length; i++) {
			s.add(i);
		}
		
		while (s.size() > 1) {
			Integer a = s.pop();
			Integer b = s.pop();
			
			if (matrix[a][b]) {
				s.add(b);
			} else {
				s.add(a);
			}
		}
		
		Integer c = s.pop();
		System.out.println("Potential candidate " + c);
		for (int i = 0; i < matrix.length; i++) {
			if (i != c && !matrix[i][c]) {
				return -1;
			}
		}
		
		
		return c;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean[][] MATRIX = {	{false, true, true, true}, 
								{true, false, true, true},
								{false, false, false, false}, 
								{false, false, true, false}};
		System.out.println(getCelebrity(MATRIX));
	}

}
