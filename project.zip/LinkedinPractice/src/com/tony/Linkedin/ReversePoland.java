package com.tony.Linkedin;

import java.util.Stack;

public class ReversePoland {

	public static int eval(String[] tokens) {	// tokens is in reverse poland reprensentation
		String operator = "+-*/";		
		Stack<String> stack = new Stack<String>();
		
		for (String t : tokens) {
			if (!operator.contains(t)) {
				stack.push(t);
			} else {
				int a = Integer.valueOf(stack.pop());
				int b = Integer.valueOf(stack.pop());
				switch (t.charAt(0)) {
					case '+':
						stack.push(String.valueOf(a + b));
						break;
					case '-':
						stack.push(String.valueOf(b - a));
						break;
					case '*':
						stack.push(String.valueOf(a * b));
						break;
					case '/':
						stack.push(String.valueOf(b / a));
						break;
				}
			}
		}
		
		if (stack.isEmpty()) return 0;
		
		return Integer.valueOf(stack.pop());
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
