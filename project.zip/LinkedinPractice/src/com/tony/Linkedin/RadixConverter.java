package com.tony.Linkedin;

public class RadixConverter {

	public static String convert(int num, int base) {
		if (base < 0) return "";
		if (base == 10) return String.valueOf(num);
		
		String result = "";
		while (num != 0) {
			result = getRepresentation(num % base, base) + result;
			num = num / base;
		}
		
		return result;
	}
	
	private static String getRepresentation(int num, int base) {
		if (base <= 10) return String.valueOf(num);
		
		return String.valueOf( (char) (65 + num - 11)	);
	}
	
	public static Integer convert(String s, int base) {
		if (s.length() == 0 && base < 0) {
			return null;
		}
		if (base == 10) return Integer.parseInt(s);
		
		int result = 0;
		int i = 0;
		while (i < s.length()) {
			result = result
						+ getNum(s.charAt(i), base) * (int) Math.pow(base, s.length() - 1 - i);
			i++;
		}
		return result;
	}
	
	private static int getNum(char c, int base) {
		if (base <= 10) return Integer.parseInt(String.valueOf(c));
		
		
		return 11 + (c - 65);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		System.out.println(convert(343432, 10));
//		System.out.println(convert(18, 2));
//		System.out.println(convert(72, 8));
//		System.out.println(convert(187, 16));
		
		//System.out.println(convert("343432", 10));
		//System.out.println(convert("10010", 2));
		System.out.println(convert("A1B", 16));
                                                                                                                                                                                                                                                                                                                                                                               
	}

}
