package com.tony.Linkedin;

public class MaxSubArray {
	
	public static int kadane(int[] A) {
		int max_so_far = 0;
		int max_end = 0;
		
		for (int i = 0; i != A.length; i++) {
			max_end = max_end + A[i];
			if (max_end < 0) {
				max_end = 0;
			}
			if (max_so_far < max_end) {
				max_so_far = max_end;
			}
		}
		
		return max_so_far;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
