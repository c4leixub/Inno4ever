package com.tony.Power;

import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class PowersImpl implements Powers {

	private class Node implements Comparable<Node> {
		public long m;
		public long n;
		public Node(long m, long n) {
			this.m = m;
			this.n = n;
		}
		@Override
		public int compareTo(Node o) {
			if (Math.pow(m, n) < Math.pow(o.m, o.n)) {
				return -1;
			} else if (Math.pow(m, n) > Math.pow(o.m, o.n)) {
				return 1;
			}
			
			return 0;
		}
	}
	
	private PriorityQueue<Node> queue = new PriorityQueue<Node>();
	private List<Long> powers = new LinkedList<Long>();
	
	public PowersImpl() {
		queue.add(new Node(2, 2));
	}
	
	@Override
	public boolean hasNext() {
		return true;
	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub
	}

	@Override
	public Long next() {
		Node node = queue.remove();
		long output = (long) Math.pow(node.m, node.n);
		while (powers.contains(output)) {
			queue.add(new Node(node.m+1, node.n));	// log n
			queue.add(new Node(node.m, node.n+1));	// log n
			
			node = queue.remove();
			output = (long) Math.pow(node.m, node.n);
		}
		powers.add(output);
		
		queue.add(new Node(node.m+1, node.n));	// log n
		queue.add(new Node(node.m, node.n+1));	// log n
		return output;
	}

	@Override
	public void reset() {
		powers.clear();
		queue.clear();
		queue.add(new Node(2, 2));
	}
	
	public static void main(String[] args) {
		Powers p = new PowersImpl();
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		
		System.out.println("Reset");
		p.reset();
		
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		System.out.println(p.next());
		
	}

}
