package com.tony.NestedInteger;

import java.util.ArrayList;
import java.util.List;

public class NestedIntegerImpl implements NestedInteger {

	private Integer value = null;
	private List<NestedInteger> values = null;

	public NestedIntegerImpl() {
		values = new ArrayList<NestedInteger>();
	}

	public NestedIntegerImpl(Integer value) {
		super();
		if (value == null)
			values = new ArrayList<NestedInteger>();
		else
			this.value = value;
	}

	public NestedIntegerImpl(List<NestedInteger> values) {
		super();
		this.values = values;
	}

	@Override
	public boolean isInteger() {
		return value != null;
	}

	@Override
	public Integer getInteger() {
		return value;
	}

	@Override
	public List<NestedInteger> getList() {
		return values;
	}

	public static int getNestedSum(NestedInteger n) {
		return _getNestedSum(n, 1);
	}

	private static int _getNestedSum(NestedInteger n, int depth) {
		if (n.isInteger()) {
			return n.getInteger() * depth;
		}
		
		int sum = 0;
		for (NestedInteger i : n.getList()) {
			if (i.isInteger()) {
				sum += i.getInteger() * depth;
			} else {
				sum += _getNestedSum(i, depth + 1);
			}
		}
		
		return sum;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
