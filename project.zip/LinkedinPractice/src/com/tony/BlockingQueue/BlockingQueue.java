package com.tony.BlockingQueue;

import java.util.LinkedList;
import java.util.List;

public class BlockingQueue {

	private List queue = new LinkedList();
	private int limit = 10;

	public BlockingQueue(int limit) {
		this.limit = limit;
	}
	
	public synchronized void enqueue(Object item) throws InterruptedException {
		while (queue.size() == limit) {
	        System.out.println("enqueue wait");
			wait();
		}
		
		// Notify all the threads that are waiting 
		if (queue.size() == 0) {
			System.out.println("enqueue notifyAll");
			notifyAll();
		}
		
		queue.add(item);
	}
	
	public synchronized Object dequeue() throws InterruptedException {
		while (queue.size() == 0) {
	        System.out.println("dequeue wait");
			wait();
		}
		
		if (queue.size() == limit) {
			System.out.println("dequeue notifyAll");
			notifyAll();
		}
		
		return queue.remove(0);
	}

}
