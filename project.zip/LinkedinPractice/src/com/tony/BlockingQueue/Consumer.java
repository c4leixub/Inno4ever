package com.tony.BlockingQueue;

public class Consumer implements Runnable {
    // This will be assigned in the constructor
    private BlockingQueue queue = null; 
 
    public Consumer(BlockingQueue q) {
    	queue = q;
    }
 
 
    public void run() {
        int i = 0;
    	while(i != 1) { 
            try {
				doStuff();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            i++;
        }
    }
 
 
    public void doStuff() throws InterruptedException {
    	Object msg = queue.dequeue();  
    	System.out.println("Consumer consume " + msg);
    }
 
}
