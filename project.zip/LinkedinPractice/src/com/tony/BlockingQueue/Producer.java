package com.tony.BlockingQueue;

import java.util.Random;

public class Producer implements Runnable {

	private Random r = new Random();
	private BlockingQueue queue = null; 
	 
    public Producer(BlockingQueue q) {
    	queue = q;
    }
    
    public void run() {
    	int i = 0;
    	while(i != 11) { 
            try {
            	doSomething(r.nextInt());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            i++;
        }
    }
 
    public void doSomething(Object msg) throws InterruptedException {
    	queue.enqueue(msg);
    	System.out.println("Producer produce " + msg);
    }

}
