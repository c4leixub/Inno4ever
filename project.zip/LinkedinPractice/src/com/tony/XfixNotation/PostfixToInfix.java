package com.tony.XfixNotation;

import java.util.Stack;

public class PostfixToInfix {

	public static String[] convert(String[] postfix) {
		String result = "";
		String operator = "+-*/";
		Stack<String> stack = new Stack<String>();
		Stack<String> preOperations = new Stack<String>();
		
		for (String s : postfix) {
			if (operator.contains(s)) {
				String a = stack.pop();
				String b = stack.pop();
				
				if (!preOperations.empty()) {
					String op = preOperations.pop();
					if (s.equals("*") || s.equals("/")) {
						if (!isNumber(a)) {
							a = "(" + a + ")";
						}
						
						if (!preOperations.empty()) {
							op = preOperations.pop();
						}
						if (!isNumber(b) && (op.equals("+") || op.equals("-"))) {
							b = "(" + b + ")";
						}
					}
				}
				
				result = b + " " + s + " " + a ;
				
				preOperations.push(s);
				stack.push(result);
			} else {
				stack.push(s);
			}
		}
		
		return result.split(" ");
	}
	
	public static boolean isNumber(String s) {
		try {
			Integer.parseInt(s);
		} catch (Exception e) {
			return false;
		}
 		
		return true;
	}
	 
	public static void display(String[] f) {
		for (String s : f) {
			System.out.print(s);
			System.out.print(" ");
		}
		System.out.println();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		display(new String[] {"1", "2", "3", "+", "-"});
		display(convert(new String[] {"1", "2", "3", "+", "-"}));
		System.out.println();
		display(new String[] {"1", "2", "3", "*", "-"});
		display(convert(new String[] {"1", "2", "3", "*", "-"}));
		System.out.println();
		display(new String[] {"1", "2", "3", "+", "/"});
		display(convert(new String[] {"1", "2", "3", "+", "/"}));
		System.out.println();
		display(new String[] {"1", "2", "+", "3", "/"});
		display(convert(new String[] {"1", "2", "+", "3", "/"}));
		System.out.println();
		display(new String[] {"1", "2", "+", "3", "4", "+", "/"});
		display(convert(new String[] {"1", "2", "+", "3", "4", "+", "/"}));
		System.out.println();
	}

}
