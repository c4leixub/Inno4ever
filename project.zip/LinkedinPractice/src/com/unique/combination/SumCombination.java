package com.unique.combination;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SumCombination {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer> comb = new ArrayList<Integer>();
		comb.add(1);
		comb.add(2);
		Combination c1 = new Combination(comb);
		
		List<Integer> comb2 = new ArrayList<Integer>();
		comb2.add(2);
		comb2.add(1);
		Combination c2 = new Combination(comb2);
		
		Set<Combination> s = new HashSet<Combination>();
		s.add(c1);
		System.out.println(s.contains(c2));
		
		System.out.println(c1.equals(c2));
		
		
		System.out.println(getSumCombination(2));
		System.out.println(getSumCombination(3));
		System.out.println(getSumCombination(4));
	}
	
	public static Set<Combination> getSumCombination(int i) {
		Set<Combination> result = new HashSet<Combination>();
		List<Integer> comb = new ArrayList<Integer>();
		if (i == 0 || i == 1) {
			comb.add(i);
			result.add(new Combination(comb));
		} else if (i == 2) {
			comb.add(1);
			comb.add(1);
			result.add(new Combination(comb));
		} else {
			Set<Combination> preResult = getSumCombination(i-1);
			for (Combination c : preResult) {
				
				List<Integer> temp = c.getNumbers();
				for (int j = 0; j != temp.size(); j++) {
					comb = new ArrayList<Integer>(temp);
					comb.set(j, comb.get(j) + 1);
					result.add(new Combination(comb));
				}
				
				comb = new ArrayList<Integer>(temp);
				comb.add(1);
				result.add(new Combination(comb));
			}
		}
		
		return result;
	}
	
	private boolean containCombination(Combination c, Set<Combination> set) {
		for (Combination k : set) {
			if (k.equals(c)) {
				return true;
			}
		}
		return false;
	}

}
