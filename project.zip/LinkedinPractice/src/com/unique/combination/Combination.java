package com.unique.combination;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Combination {

	private List<Integer> numbers = new ArrayList<Integer>();
	
	public Combination(List<Integer> numbers) {
		super();
		this.numbers = numbers;
	}
	
	public List<Integer> getNumbers() {
		return numbers;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Combination other = (Combination) obj;
		if (numbers == null) {
			if (other.numbers != null)
				return false;
		} else if (!equalsHelper(other))
			return false;
		
		return true;
	}
	
	private boolean equalsHelper(Combination other) {
		
		HashMap<Integer, Integer> countMap = new HashMap<Integer, Integer>();
		for (Integer i : other.getNumbers()) {
			if(countMap.containsKey(i)) {
				countMap.put(i, countMap.get(i).intValue() + 1);
			} else {
				countMap.put(i, 1);
			}
		}
		
		for (Integer i : this.numbers) {
			if(countMap.containsKey(i)) {
				if (countMap.get(i) == 1) {
					countMap.remove(i);
				} else {
					countMap.put(i, countMap.get(i).intValue() - 1);
				}
			}
		}
		
		return countMap.isEmpty();
	}
	
	public String toString() {
		return numbers.toString();
	}

}
