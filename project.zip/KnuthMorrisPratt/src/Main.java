public class Main {

	// Knuth Morris Pratt Algorithm to check w is the substring of s
	public static int kmp(char[] w, char[] s, int[] t) {

		int m = 0;
		int i = 0;
		while (((m + i) < s.length) && (i < w.length)) {
			if (s[m + i] != w[i]) {
				//m += i - t[i];
				m += i;
				
				if (i > 0) i = 0; //i = t[i];
			}
			i++;
		}
		
		if (i == w.length) {
			return m;
		} else {
			return -1;
		}
	}
	
	public static void prefixFunction(char[] w, char[] s, int[] t) {
		int q = 0;
		for (int i = 0; i != s.length; i++) {
			while (q > 0 && w[q+1] != s[i]) {
				t[q] = q;
				
				if (w[q+1] == s[i]) q++;
				if (q == w.length) {
					t[q] = q;
				}
			}
		}
		
		for (int i = 0; i != t.length; i++) {
			System.out.print(t[i] + " ");
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "abcdefg";
		String w = "cde";
		System.out.println(kmp(w.toCharArray(), s.toCharArray(), new int[w.length()]));
		
		int[] prefix = new int["ababaca".length()];
		prefixFunction("ababaca".toCharArray(), "ababaca".toCharArray(), prefix);
		System.out.println(prefix[1]);
	}

}
